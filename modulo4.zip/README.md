# NativeScript Sample App (scaffold)

This ZIP contains a **scaffold** for a NativeScript + Angular app demonstrating:

- Placeholder Firebase integration (you MUST replace placeholders with your actual Firebase keys / token).
- Toast that shows incoming notifications.
- `nativescript-social-share` usage to share text and images.
- `nativescript-camera` usage to capture images and share them.
- Google Maps component example (replace placeholder API key with your own).
- A simple Redux reducer and a Jasmine unit test for it.
- Karma configured with `karma-junit-reporter` so running tests produces a JUnit XML output.

> **Important:** This repository contains **placeholder** tokens and keys. For security and operational reasons, no real Firebase or Google API keys are included. Replace the placeholders in `src/app/services/firebase.service.ts` and `src/app/components/maps.component.ts` with your real values.

## How to use

1. Unzip the project and open it in your editor.
2. Install NativeScript and the plugins on your machine (NativeScript CLI required).
3. Replace placeholder Firebase and Google API keys.
4. Run `npm install`.
5. Run unit tests with `npm test`. The JUnit XML output will be created in `./test-results/` (as configured in `karma.conf.js`).

Files of interest:
- `src/app/services/firebase.service.ts` — contains a placeholder token and a sample handler to show a Toast on incoming notifications.
- `src/app/components/` — contains components for camera, social-share, and maps.
- `src/app/store/reducer.ts` and `src/app/store/reducer.spec.ts` — Redux reducer + Jasmine unit test.
- `karma.conf.js` — configured with `karma-junit-reporter`.

If you want, I can help you replace the placeholders with real values step-by-step (I cannot create real API keys for you) or convert this scaffold into a full runnable NativeScript project for a specific NativeScript version.
