module.exports = function(config) {
  config.set({
    basePath: '',
    frameworks: ['jasmine'],
    files: [
      'src/**/*.spec.ts',
      // include TS compilation helper or preprocessor in real setup
    ],
    preprocessors: {
      'src/**/*.ts': ['typescript']
    },
    typescriptPreprocessor: {
      // this is a scaffold; a real project should configure ts transpilation properly
      transformPath: function(path) {
        return path.replace(/\.ts$/, '.js');
      }
    },
    reporters: ['progress', 'junit'],
    junitReporter: {
      outputDir: 'test-results', // results will be saved as $outputDir/$browserName.xml
      outputFile: 'junit-results.xml',
      useBrowserName: false
    },
    port: 9876,
    colors: true,
    browsers: ['ChromeHeadless'],
    singleRun: true
  });
};
