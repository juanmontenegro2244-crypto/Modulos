/*
 social-share-image.component.ts - shows how to share an image using nativescript-social-share
*/
export class SocialShareImageComponent {

  shareImage(localImagePath: string) {
    // Pseudocode. Real call:
    // SocialShare.shareImage(localImagePath);
    console.log('shareImage() called for', localImagePath);
  }
}
