/*
 maps.component.ts - demonstrates a Google Maps component with a single marker

 Replace GOOGLE_MAPS_API_KEY_PLACEHOLDER with your actual Google Maps SDK API key for Android/iOS.
*/
export const GOOGLE_MAPS_API_KEY = 'GOOGLE_MAPS_API_KEY_PLACEHOLDER';

export class MapsComponent {
  initMap(mapInstance: any) {
    // Pseudocode for nativescript-google-maps-sdk:
    // mapInstance.addMarker({lat: 4.710989, lng: -74.072090, title: 'Marker', snippet: 'Bogotá example'});
    console.log('initMap called. Add marker at sample coords (Bogotá).');
  }
}
