/*
 social-share-text.component.ts - shows how to share text using nativescript-social-share
*/
export class SocialShareTextComponent {

  shareText() {
    // Pseudocode. In a real NativeScript app:
    // import { SocialShare } from 'nativescript-social-share';
    // SocialShare.shareText('Hello from NativeScript!');
    console.log('shareText() called - replace with nativescript-social-share shareText call.');
  }
}
