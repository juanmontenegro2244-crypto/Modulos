/*
 Simple wrapper for showing a toast using nativescript-toast plugin (pseudocode).
 In a real NativeScript app you would import 'nativescript-toast' and call Toast.makeText(...)
 Here we show a typed wrapper to indicate where to place the toast logic.
*/
export function showToast(message: string) {
  // Replace with: import * as Toast from 'nativescript-toast'; Toast.makeText(message).show();
  console.log('[TOAST]', message);
}
