/*
 A tiny Redux reducer (TypeScript) for demonstration.
*/
export interface State {
  count: number;
}

export const initialState: State = {
  count: 0
};

export const INCREMENT = 'INCREMENT';
export const DECREMENT = 'DECREMENT';

export function counterReducer(state: State = initialState, action: any): State {
  switch (action.type) {
    case INCREMENT:
      return { ...state, count: state.count + 1 };
    case DECREMENT:
      return { ...state, count: state.count - 1 };
    default:
      return state;
  }
}
