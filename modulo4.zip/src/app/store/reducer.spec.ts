import { counterReducer, initialState, INCREMENT, DECREMENT } from './reducer';

describe('counterReducer', () => {
  it('should return the initial state when action is unknown', () => {
    const state = counterReducer(undefined, { type: 'UNKNOWN' });
    expect(state).toEqual(initialState);
  });

  it('should increment', () => {
    const state = counterReducer(initialState, { type: INCREMENT });
    expect(state.count).toBe(1);
  });

  it('should decrement', () => {
    const s = { count: 5 };
    const state = counterReducer(s as any, { type: DECREMENT });
    expect(state.count).toBe(4);
  });
});
