/*
  firebase.service.ts - SAMPLE / PLACEHOLDER

  THIS FILE CONTAINS placeholders. Replace with your Firebase project's configuration
  and the real token/credentials you obtain from Firebase.

  The token below is a sample string and NOT a real credential.

  The service demonstrates:
  - where to store the FCM token (placeholder)
  - how to show a Toast when a push notification arrives
*/

import { Injectable } from '@angular/core';

// Placeholder token: REPLACE with your device token or server key as required.
export const SAMPLE_FIREBASE_TOKEN = 'REPLACE_WITH_YOUR_FIREBASE_TOKEN';

@Injectable({
  providedIn: 'root'
})
export class FirebaseService {

  constructor() { }

  // Call this to initialise Firebase in your app (platform-specific plugin code required)
  initFirebase() {
    // Example pseudocode: register for push notifications, get token and set handlers
    // Actual implementation depends on the NativeScript Firebase plugin you use (e.g. @nativescript/firebase)
    console.log('Firebase init (placeholder). Token:', SAMPLE_FIREBASE_TOKEN);
  }

  // Example handler to be called when a notification arrives.
  // In a real app the plugin will call your callback.
  onNotificationReceived(payload: any, toastFn: (message: string) => void) {
    const title = payload?.title || 'Notificación';
    const body = payload?.body || JSON.stringify(payload);
    toastFn(`${title}: ${body}`);
    // further processing...
  }
}
