
import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { NativeScriptModule } from 'nativescript-angular/nativescript.module';
import { NativeScriptFormsModule } from 'nativescript-angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { ListComponent } from './components/list/list.component';
import { DetailComponent } from './components/detail/detail.component';
import { SearchComponent } from './components/search/search.component';
import { ItemService } from './services/item.service';
import { MinLengthValidator } from './validators/min-length.validator';

@NgModule({
  declarations: [ListComponent, DetailComponent, SearchComponent, MinLengthValidator],
  imports: [NativeScriptModule, NativeScriptFormsModule, AppRoutingModule],
  providers: [ItemService],
  bootstrap: [SearchComponent],
  schemas: [NO_ERRORS_SCHEMA]
})
export class AppModule {}
