
import { Injectable } from '@angular/core';

export interface Item { id: number; title: string; description: string; category: string; }

@Injectable()
export class ItemService {
  private items: Item[] = [];
  private idCounter = 1;

  constructor() {
    for (let i = 0; i < 8; i++) this.addRandom();
  }

  list() { return this.items.slice(); }

  getById(id: number) { return this.items.find(i => i.id === id); }

  addRandom() {
    const it: Item = {
      id: this.idCounter++,
      title: 'Item ' + Math.floor(Math.random() * 1000),
      description: 'Descripción aleatoria ' + Math.random().toString(36).slice(2,12),
      category: ['A','B','C'][Math.floor(Math.random()*3)]
    };
    this.items.unshift(it);
    return it;
  }

  update(item: Item) {
    const idx = this.items.findIndex(i => i.id === item.id);
    if (idx >= 0) this.items[idx] = { ...item };
  }
}
