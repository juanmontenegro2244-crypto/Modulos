
import { Component, OnInit } from '@angular/core';
import { ItemService, Item } from '../../services/item.service';
import { RouterExtensions } from 'nativescript-angular/router';
import { action } from '@nativescript/core/ui/dialogs';
import * as Toast from 'nativescript-toast';

@Component({
  selector: 'ns-list',
  templateUrl: './list.component.html'
})
export class ListComponent implements OnInit {
  items: Item[] = [];

  constructor(private svc: ItemService, private routerExt: RouterExtensions) {}

  ngOnInit() {
    this.items = this.svc.list();
  }

  onPullToRefresh(args) {
    setTimeout(() => {
      this.svc.addRandom();
      this.items = this.svc.list();
      args.object.refreshing = false;
      Toast.makeText("Listado actualizado").show();
    }, 900);
  }

  openDetail(item: Item) {
    this.routerExt.navigate([`/detail/${item.id}`]);
  }

  async changeCategory(item: Item) {
    const choice = await action({
      message: "Selecciona categoría",
      cancelButtonText: "Cancelar",
      actions: ['A','B','C']
    });
    if (choice && choice !== 'Cancelar') {
      item.category = choice;
      this.svc.update(item);
      Toast.makeText("Categoría actualizada").show();
      this.items = this.svc.list();
    }
  }
}
