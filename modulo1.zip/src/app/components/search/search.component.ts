
import { Component } from '@angular/core';
import { RouterExtensions } from 'nativescript-angular/router';
import { ItemService, Item } from '../../services/item.service';

@Component({
  selector: 'ns-search',
  templateUrl: './search.component.html'
})
export class SearchComponent {
  query = '';
  results: Item[] = [];

  constructor(private routerExt: RouterExtensions, private svc: ItemService) {
    this.results = svc.list();
  }

  onSearch() {
    const q = (this.query || '').toLowerCase();
    this.results = this.svc.list().filter(i =>
      i.title.toLowerCase().includes(q) || i.description.toLowerCase().includes(q)
    );
  }

  openList() { this.routerExt.navigate(['/list']); }

  openDetail(item: Item) { this.routerExt.navigate([`/detail/${item.id}`]); }
}
