
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ItemService, Item } from '../../services/item.service';
import { RouterExtensions } from 'nativescript-angular/router';

@Component({
  selector: 'ns-detail',
  templateUrl: './detail.component.html'
})
export class DetailComponent implements OnInit {
  item: Item;
  id: number;
  @ViewChild('animBtn', { static: false }) animBtn: ElementRef;

  constructor(private route: ActivatedRoute, private svc: ItemService, private routerExt: RouterExtensions) {}

  ngOnInit() {
    this.id = +this.route.snapshot.params['id'];
    this.item = Object.assign({}, this.svc.getById(this.id));
  }

  save() {
    this.svc.update(this.item);
    this.routerExt.back();
  }

  animateButton() {
    const btn = this.animBtn.nativeElement;
    btn.animate({ rotate: 360, duration: 600 })
      .then(() => btn.animate({ rotate: 0, duration: 0 }));
  }
}
