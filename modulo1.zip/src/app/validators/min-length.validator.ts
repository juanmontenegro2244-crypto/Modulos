
import { Directive, Input } from '@angular/core';
import { NG_VALIDATORS, Validator, AbstractControl, ValidationErrors } from '@angular/forms';

@Directive({
  selector: '[minLengthCustom]',
  providers: [{ provide: NG_VALIDATORS, useExisting: MinLengthValidator, multi: true }]
})
export class MinLengthValidator implements Validator {
  @Input('minLengthCustom') minLength: string;

  validate(control: AbstractControl): ValidationErrors | null {
    const min = parseInt(this.minLength || '0', 10);
    if (!control.value) return null;
    return control.value.length >= min ? null : {
      'minLengthCustom': { requiredLength: min, actualLength: control.value.length }
    };
  }
}
